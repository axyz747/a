#include<stdio.h>
#include<string.h>
int main(){
	char str[]="Hello world", str1[20];
	int i, n;
	n=strlen(str);
	printf("And operation : ");
	for(i=0;i<n;i++){
		str1[i]=str[i]&127;
		printf("%c",str1[i]);
	}
	printf("\n");
//	printf("Hello world AND 127 : %s", str1);
	printf("XOR operation : ");
	for(i=0;i<n;i++){
		str1[i]=str[i]^127;
		printf("%c",str1[i]);
	}
	printf("\n");
//	printf("Hello world OR 127 : %s", str1);
	printf("Or opeartion : ");
	for(i=0;i<n;i++){
		str1[i]=str[i]|127;
		printf("%c",str1[i]);
	}
	printf("\n");
//	printf("Hello world XOR 127 : %s", str1);
	return 0;
}
