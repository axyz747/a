#include<stdio.h>
#define MAX 99
int a[10][10],n,visited[10];
void adj(int);
int main(){
	int i,j,root;
	printf("Enter number of nodes : ");
	scanf("%d",&n);
	printf("\nEnter adjacency matrix : \n");
	for(i=0;i<n;i++)
	for(j=0;j<n;j++){
		scanf("%d",&a[i][j]);
		a[i][i]=0;
	}
	printf("\nEnter root node : ");
	scanf("%d",&root);
	adj(root);
} 
void adj(int k){
	int visited[10],i,j,count=0,nextnode,path[10],min;
	for(i=0;i<n;i++)
	visited[i]=0;
	nextnode=k;
	visited[k]=1;
	while(count<n-1){
		min=MAX;
		for(j=0;j<n;j++){
			if(a[nextnode][j]<min&&!visited[j]){
				min=a[nextnode][j];
			}
			visited[j]=1;
			path[count]=j;
			nextnode=j;
		}
		count++;
	}
	printf("Broad cast tree : %d",k);
	for(i=0;i<n-1;i++){
		printf("->%d",path[i]);
	}
	
	
}
