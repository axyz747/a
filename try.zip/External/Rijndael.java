import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.SecretKey;
import javax.crypto.KeyGenerator;
import java.util.*;

class Rijndael{
	public static void main(String[] args)throws Exception {
		try{
			Scanner sc=new Scanner(System.in);
			System.out.print("Enter message to encrypt : ");
			String message=sc.nextLine();
			System.out.print("Enter SecretKey of length exactly 16 bytes(characters): ");
			String skey=sc.nextLine();
		/*	if(skey.length()!=16){
				throw InvalidKeyLength("Enter a SecretKey of length exactly 16 characters .");
			} */
			//SecretKey key=new SecretKeySpec(skey.getBytes(),"AES");
			KeyGenerator keyGeneartor =KeyGenerator.getInstance("AES");
			keyGeneartor.init(128);
			SecretKey key=keyGeneartor.generateKey(); // using key generator


			Cipher cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.ENCRYPT_MODE, key);
			byte[] encryptedBytes= cipher.doFinal(message.getBytes());
			String encryptedString = Base64.getEncoder().encodeToString(encryptedBytes);
			System.out.println("Encrypted message is : "+encryptedString);

			cipher.init(Cipher.DECRYPT_MODE,key);
			byte[] decrytpedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedString));// you can directly use encryptedBytes
			String decryptedString = new String(decrytpedBytes);
			System.out.println("Decrypted message is : "+decryptedString);

			sc.close();
		}
		catch (Exception e){
			e.printStackTrace();
		}
	}
}