import java.io.*;
import java.util.*;
class Substitution{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String a="abcdefghijklmopqrstuvwxyz";
		String b="zyxwvutsrpqomlkjihgfedcba";
		String encrypted="", decrypted="";
		System.out.print("Enter a String to encrypt : ");
		String enc=sc.nextLine();
		enc=enc.toLowerCase();
		for(int i=0;i<enc.length();i++){
			int pos=a.indexOf(enc.charAt(i));
			char encChar=b.charAt(pos);
			encrypted+=encChar;
		}
		System.out.print("\nEncrypted String is : "+encrypted);

		for(int i=0;i<encrypted.length();i++){
			int pos = b.indexOf(encrypted.charAt(i));
			char decChar=a.charAt(pos);
			decrypted+=decChar;
		}
		System.out.println("\nDecrypted String is : "+decrypted);
	}
	

}