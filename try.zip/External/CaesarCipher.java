import java.io.*;
import java.util.*;

public class CaesarCipher{
	public static final String ALPHABET="abcdefghijklmopqrstuvwxyz";
	public static String encrypt(String inputStr, int shiftKey){
		inputStr=inputStr.toLowerCase();
		String encryptString="";
		for(int i=0;i<inputStr.length();i++){
			int pos=ALPHABET.indexOf(inputStr.charAt(i));
			int encryptPos=(pos+shiftKey)%26;
			encryptString +=ALPHABET.charAt(encryptPos);
		}
		return encryptString;
	}
	public static String decrypt(String inputStr, int shiftKey){
		inputStr=inputStr.toLowerCase();
		String decryptString="";
		for(int i=0;i<inputStr.length();i++){
			int pos=ALPHABET.indexOf(inputStr.charAt(i));
			int decryptPos=(pos-shiftKey)%26;
			if(decryptPos < 0){
				decryptPos=decryptPos+ALPHABET.length();
			}
			decryptString+=ALPHABET.charAt(decryptPos);
		}
		return decryptString;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter a string to Encrypt : ");
		String enc=sc.nextLine();
		System.out.print("\nEnter Shiftkey : ");
		int sk=sc.nextInt();
		System.out.println("Encrypted String is : "+encrypt(enc,sk ));
		System.out.println("Decrypted String is : "+decrypt(encrypt(enc, sk), sk));
	}
}