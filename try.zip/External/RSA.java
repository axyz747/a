import java.security.KeyPair;

import java.security.KeyPairGenerator;

import java.security.PrivateKey;

import java.security.PublicKey;

import java.util.Base64;

import javax.crypto.Cipher;



public class RSA{
    public static void main(String[] args) throws Exception {

        // Generate public and private keys

        KeyPair keyPair = generateKeyPair();

        PublicKey publicKey = keyPair.getPublic();

        PrivateKey privateKey = keyPair.getPrivate();



        // Encrypt the message

        String originalMessage = "Test Message";

        byte[] encryptedBytes = encrypt(originalMessage, publicKey);

        String encryptedMessage = Base64.getEncoder().encodeToString(encryptedBytes);



        // Decrypt the message

        byte[] decodedBytes = Base64.getDecoder().decode(encryptedMessage);

        String decryptedMessage = decrypt(decodedBytes, privateKey);



        // Print original message, encrypted message, and decrypted message

        System.out.println("Original Message: " + originalMessage);

        System.out.println("Encrypted Message: " + encryptedMessage);

        System.out.println("Decrypted Message: " + decryptedMessage);

    }



    public static KeyPair generateKeyPair() throws Exception {

        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");

        keyPairGenerator.initialize(2048); // Key size

        return keyPairGenerator.generateKeyPair();

    }

    public static byte[] encrypt(String plainText, PublicKey publicKey) throws Exception {

        Cipher cipher = Cipher.getInstance("RSA");

        cipher.init(Cipher.ENCRYPT_MODE, publicKey);

        return cipher.doFinal(plainText.getBytes());

    }



    public static String decrypt(byte[] encryptedBytes, PrivateKey privateKey) throws Exception {

        Cipher cipher = Cipher.getInstance("RSA");

        cipher.init(Cipher.DECRYPT_MODE, privateKey);

        byte[] decryptedBytes = cipher.doFinal(encryptedBytes);

        return new String(decryptedBytes);

    }

}

