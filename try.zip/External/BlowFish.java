import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.Cipher;
import java.util.*;

class BlowFish{
	public static void main(String[] args) throws Exception {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter message to encrypt : ");
		String message = sc.nextLine();
		System.out.print("\nEnter SecretKey : ");
		String skey=sc.nextLine();

		SecretKey key = new SecretKeySpec(skey.getBytes(),"BlowFish");

		Cipher cipher = Cipher.getInstance("BlowFish");
		cipher.init(Cipher.ENCRYPT_MODE, key);

		byte[] encryptedBytes=cipher.doFinal(message.getBytes());
		String encryptedString = Base64.getEncoder().encodeToString(encryptedBytes);
	//	String encryptedString= new String(encryptedBytes);
		System.out.println("Encrypted message is : "+encryptedString);
		
		cipher.init(Cipher.DECRYPT_MODE, key);

		byte[] decryptedBytes=cipher.doFinal(Base64.getDecoder().decode(encryptedString));
	//	String decrptedString = Base64.getEncoder().encodeToString(decryptedBytes);
		String decrptedString = new String(decryptedBytes);
		System.out.println("Decrypted message is : "+decrptedString);
	}
}