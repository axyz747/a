#include<stdio.h>
#include<string.h>
int main(){
	char data[20],genpoly[10],pdata[30], aux[30], rem[10],tdata[30];
	int i,j,k,datalen,genlen,pdatalen, count;
	printf("Enter data to be transmitted : ");
	scanf("%s",data);
	printf("Enter generator polynomial : ");
	scanf("%s",genpoly);
	datalen=strlen(data);
	for(i=0;i<datalen;i++){
		pdata[i]=data[i];
		tdata[i]=data[i];
	}
	genlen=strlen(genpoly);
//	printf("genlen %d",genlen);
	for(i=datalen;i<datalen+genlen-1;i++){
		pdata[i]='0';
	}
	printf("Data with padded %d 0's :%s",genlen-1,pdata);
	pdatalen=strlen(pdata);
	//crc operation
	for(i=0;i<pdatalen-genlen;i++){
			if(pdata[i]=='1'){
				//xor opearation
				for(j=i,k=0;j<genlen;j++,k++)
				pdata[j]=((pdata[j]==genpoly[k])?'0':'1');
			}
	}
	//evaluating remainder 
	for(i=0;i<pdatalen;i++){
		if(pdata[i]=='1')
		break;
	}
	for(j=0;j<genlen;j++){
		rem[j]=pdata[i];
		i++;
	}
	printf("\nremainder is : %s",rem);
	for(i=datalen,j=0;i<datalen+strlen(rem);i++,j++){
		tdata[i]=rem[j];
	}
	printf("\nTransported data is : %s",tdata);
	//checking
	for(i=0;i<strlen(tdata)-genlen;i++){
		if(tdata[i]=='1'){
			for(j=i,k=0;j<genlen;j++,k++){
			//	count++;
				tdata[j]=((tdata[j]==genpoly[k])?'0':'1');
			}
		}
	}
	printf("\nReceived data is : %s, %d",tdata, count);
	for(i=0;i<strlen(tdata);i++){
		if(tdata[i]=='1'){
			printf("\nWrong transmission");
			return 0;
		}
	}
	printf("\nsuccessful Transmission");
	return 0;
}

