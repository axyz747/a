#include <stdio.h>
#define MAX 99
int a[10][10], n, visited[10];

void dfs(int);

int main() {
    int i, j, root;
    printf("Enter number of nodes: ");
    scanf("%d", &n);
    printf("\nEnter adjacency matrix: \n");
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            scanf("%d", &a[i][j]);
        }
    }
    printf("\nEnter root node: ");
    scanf("%d", &root);
    for (i = 0; i < n; i++) {
        visited[i] = 0; // Initialize all nodes as not visited
    }
    printf("Broadcast tree: %d", root);
    dfs(root);
    printf("\n");
    return 0;
}

void dfs(int node) {
    int i;
    visited[node] = 1;
    for (i = 0; i < n; i++) {
        if (a[node][i] == 1 && !visited[i]) {
            printf(" -> %d", i);
            dfs(i);
        }
    }
}
