import javax.crypto.Cipher;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.SecretKey;
import java.util.Base64;
import java.util.Scanner;
class DES{
	public static void main(String[] args) throws Exception {
		Scanner sc=new Scanner(System.in);
		System.out.print("enter message to Encrypt : ");
		String message=sc.nextLine();
		System.out.print("Enter SecretKey of 8 characters : ");
		String key=sc.nextLine();
		String encrypted = encrypt(message, key);
		System.out.print("Encrypted message is : "+encrypted);
		String decrypted = decrypt(encrypted, key);
		System.out.print("\nDecrypted message is : "+decrypted);
		sc.close();
	}
	public static String encrypt(String message, String key) throws Exception{
		DESKeySpec deskeyspec=new DESKeySpec(key.getBytes());
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
		SecretKey skey=keyFactory.generateSecret(deskeyspec);

		Cipher cipher =Cipher.getInstance("DES/ECB/PKCS5Padding");
		cipher.init(Cipher.ENCRYPT_MODE, skey);

		byte[] encryptedBytes=cipher.doFinal(message.getBytes());
		String encryptedString = Base64.getEncoder().encodeToString(encryptedBytes);

		return encryptedString;

	}
	public static String decrypt(String message, String key) throws Exception{
		DESKeySpec deskeyspec = new DESKeySpec(key.getBytes());
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
		SecretKey skey=keyFactory.generateSecret(deskeyspec);

		Cipher cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
		cipher.init(Cipher.DECRYPT_MODE, skey);

		byte[] decryptedBytes=cipher.doFinal(Base64.getDecoder().decode(message));
		//String decryptedString = Base64.getEncoder().encodeToString(decryptedBytes);
		return new String(decryptedBytes);
	}
}