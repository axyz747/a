import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.*;
import javax.crypto.Cipher;
public class RSA1{
	public static void main(String[] args)throws Exception {
		KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
		keyPairGenerator.initialize(2048);
		KeyPair keyPair=keyPairGenerator.generateKeyPair();
		PublicKey publicKey = keyPair.getPublic();
		PrivateKey privateKey = keyPair.getPrivate();
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter message to encrypt : ");
		String message = sc.nextLine();
		//String message = "hello world";

		Cipher cipher = Cipher.getInstance("RSA");
		
		cipher.init(cipher.ENCRYPT_MODE, publicKey);
		byte[] encryptedBytes= cipher.doFinal(message.getBytes());
		String encryptedString = Base64.getEncoder().encodeToString(encryptedBytes);
		System.out.println("Encrypted message is : "+encryptedString);

		cipher.init(cipher.DECRYPT_MODE, privateKey);
		byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
		String decryptedString = new String(decryptedBytes);
		System.out.println("Decrypted message is : "+decryptedString);
	}
}