#include<stdio.h>
#include<string.h>
int main(){
	char str[20], str1[20];
	int i, len;
	printf("Enter a String : ");
	gets(str);
	len=strlen(str);
	for(i=0;i<len;i++){
		str1[i]=str[i]^0;
	}
	printf("Result of XOR 0 is : %s", str1);
	return 0;
}
