#include<stdio.h>
#include<conio.h>
#include<string.h>
#define N strlen(g)
char t[28], cs[28], g[28];
int a,e,c,b;
void xor(){
	for(c=1;c<N;c++){
		cs[c]=((cs[c]==g[c])?'0':'1');
	}
}
void crc(){
	for(e=0;e<N;e++)
	cs[e]=t[e];
	do{
		if(cs[0]=='1')
		xor();
		for(c=0;c<N-1;c++)
		cs[c]=cs[c+1];
		cs[c]=t[e++];
	}while(e<a+N-1);
}
void main(){
	int flag;
	printf("\n1.crc12\n2.crc16\n3.crc ccit\n4.exit\nEnter your option.");
	scanf("%d",&b);
	switch(b){
		case 1:printf("crc 12");
		break;
		case 2:printf("crc 16");
		break;
		case 3:printf("crc ccit");
		break;
		case 4:exit(0);
	}
	printf("\nEnter data: ");
	scanf("%s",t);
	printf("\n enter generating polynomial : ");
	scanf("%s",&g);
	a=strlen(t);
	for(e=a;e<a+N-1;e++)
	t[e]='0';
	printf("Modified data is : %s", t);
	crc();
	printf("checksum is : %s",cs);
	for(e=a;e<a+N-1;e++)
	t[e]=cs[e-1];
	printf("final codeword is : %s ",t);
}
