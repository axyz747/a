<?php
	$num = 2;
	echo "prime numbers up 100 : \n";
	while( $num < 100){
		$flag = true;
		for ($i = 2; $i <= $num/2; $i++){
			if (($num % $i ) == 0){
				$flag = false;
				break;
			}
		}
		if ($flag){
			echo $num, " ";
		}
		$num++;
	}
	echo "\n";
?>
