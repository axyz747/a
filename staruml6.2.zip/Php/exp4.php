<?php
	$input = "source.txt";
	$output = "dest.txt";
	if (file_exists($input)){
		$data = file_get_contents($input);
		if ($data !== false){
			if(file_put_contents($output, $data)!= false){
				echo 'data copied successfull';
			}
			else{
				echo "failed to write data to $output";
			}
		}
		else{
			echo "source file does not exist";
		}
	}
?>
