<?php
	// echo "Enter the file name : ";
	// $filename = readline();
	$filename = 'source.txt';
	if (file_exists($filename)){
		$filedata = file_get_contents($filename);
	}
	echo 'original contents : '. "$filedata"."<br>";
	echo "length of string is : ".strlen($filedata)."\n";
?> 