<?php 
	// echo "enter file name : ";
	// $filename = readline();
	$filename = 'source.txt';
	if (file_exists($filename)){
		$filedata = file_get_contents($filename);
		echo "orginal file data : ".$filedata."<br>";
		// echo "Enter a search term : ";
		// $search = readline();
		$search = 'good';

		if (strpos($filedata, $search )!== false){
			echo "'$search' found ";
		}else{
			echo "'$search' not found ";
		}
	}
?>