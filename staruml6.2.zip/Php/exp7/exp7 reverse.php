<?php 
	// echo "enter file name : ";
	// $filename = readline();
	$filename = 'source.txt';
	if (file_exists($filename)){
		$filedata = file_get_contents($filename);
		echo "orginal file data : ".$filedata."<br>";
		echo "Reversed data is : ". strrev($filedata);
	}
?>